CREATE TABLE `T_LOGIN` (

  `user` VARCHAR(10) NOT NULL,

  `password` VARCHAR(10) NULL,

  `level` INT NULL,

  PRIMARY KEY (`user`));
