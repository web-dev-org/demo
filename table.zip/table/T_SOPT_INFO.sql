CREATE TABLE `T_SOPT_INFO` (
  `spot_name` VARCHAR(50) NOT NULL,
  `spot_explain` VARCHAR(1000) NULL,
  `spot_local` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`spot_name`));